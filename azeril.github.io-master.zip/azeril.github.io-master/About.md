---
layout: page
title: "About"
description: "嘿，你总算找到我啦"
header-img: "img/plane.jpg"
---

<center>
    <p><img src="http://dreamofbook.qiniudn.com/Zero.png" align="center"></p>
</center>

Ehhhh...I know it's not a good question.

My Name is Azeril. You may find me in sites like douban.com / Goodreads.com / Facebook / Instagram / Twitter / Weibo.com, so on and so forth. It’s easy to know me. My short name is Az., quite easy to remember, right?

喜欢折腾的伪技术宅。一点点 geek，一丢丢的执著，就像吃烧烤时多少会撒一点孜然，恰到好处就够。日常之中，多的是折腾劲，也希望能添几分专注、几许勇敢。这就是我。

——Azeril


> Live long and prosper

<center>
    <p><img src="http://dreamofbook.qiniudn.com/hacker.png" align="center"></p>
</center>
