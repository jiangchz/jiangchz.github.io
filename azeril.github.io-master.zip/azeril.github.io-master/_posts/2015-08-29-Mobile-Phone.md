---  
layout: post  
title: 关于移动网络及办卡   
categories: [blog ]  
tags: [iOS,  ]
description: 关于办理手机卡的小贴士  
---  


## 关于移动网络

意大利的移动网络是联通制式（中国联通使用的网络制式占据全球 80% 的通讯市场），GSM（2G） /WCDMA（3G）/FDD-LTE（4G 意大利公开的 4G 网络）。移动 2G 的也可以用（2G 网络 移动联通都是 GSM 3G 移动是 CDMA2000 制式 4G 为覆盖不多的 TDD ）。

电信，无法使用（CDMA）。

购买电话卡，注意运营商网络制式（据以上的为准）。

意大利各大移动网络运营商 TIM WIN TRE 等提供的都是 WCDMA。当然购买前还是需要询问一下。尤其是套餐价格一类。

## 关于 iPhone 的网络制式 

iPhone 5S 使用的是小卡。特称是：nano 卡。如果卡过大需要剪卡。不过初次办理，如果有提供小卡是最好不过。

手机卡办理的一些细节可查看参考资料（第二和第三个资料）扫盲。

参考资料：

- [意大利tim网络公司什么制式的_好搜问答](http://wenda.haosou.com/q/1378238917061735)
- [关于意大利手机卡和上网套餐的选择（2015.02.08最后更新） - 意大利/梵蒂冈/圣马力诺/马耳他 - 论坛 - 穷游网](http://bbs.qyer.com/thread-843741-1.html)
- [[手机卡]意大利Tim、Vodafone、Tre、Wind手机卡服务介绍.pdf](https://docs.google.com/viewer?a=v&pid=sites&srcid=ZGVmYXVsdGRvbWFpbnxjc3N1aW1pbGFub3xneDozZDU2ZGMwYmZjOWI1ZGM)
- [意大利TIM卡支持哪些制式？求推荐便携式3G路由器。 - 问答 - 穷游网](http://m.qyer.com/ask/question/432620.html)
- [中国什么制式的4G手机意大利可以通用？ - 意大利你问我答 - 华人街网](http://www.huarenjie.com/thread-3541782-1-1.html)


------

## 其它 

* [意大利旅行，意大利货币兑换攻略（如何兑换欧元/在意大利ATM取现及刷卡） - 意大利 - 十六番](http://bbs.16fan.com/thread-348582-1-1.html)
* [世界各国电源插头插座形式 - 背包攻略](http://www.bbkz.com/guide/index.php/%E4%B8%96%E7%95%8C%E5%90%84%E5%9C%8B%E9%9B%BB%E6%BA%90%E6%8F%92%E9%A0%AD%E6%8F%92%E5%BA%A7%E5%BD%A2%E5%BC%8F)