---
layout: post
title: 帕斯捷尔纳克：唯一的日子
categories: [blog ]
tags: [Poem, ]
description:  
---

分享帕斯捷尔纳克的一首短诗《唯一的日子》


    情人们仿佛在梦中
    彼此急切地吸引。
    在高高的树梢上 
    椋鸟晒得汗涔涔。 
    
    睡眼惺忪的时针 
    懒得在表盘上旋动。
    一日长于百年 
    拥抱无止无终。