---
layout: post
title: 初次尝试：GIF 动画
categories: [blog ]
tags: [Star,]
description: Just try it，try it again
---
纯粹好奇地折腾 当然 是从最初一个小任务中牵扯出的一个分支...GIF 动画 玩一下嘛...  
拿几部经典作品先做测试。

Vertigo (1958)  

![Vertigo](http://dreamofbook.qiniudn.com/Vertigo.gif)

Shadow of a Doubt (1943)   

![Shadow of a Doubt](http://dreamofbook.qiniudn.com/ShadowofaDoubt.gif)

Notorious （1946）  

![Notorious](http://dreamofbook.qiniudn.com/Notorious.gif)  



