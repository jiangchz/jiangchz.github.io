---
layout: post
title: Safari Extensions List
categories: [blog ]
tags: [Apps, Mac, ]
description: 挂了铠甲的 Safari 原来也可以很好用
---

Safari 毕竟是 Apple 家的亲儿子 在 Mac 相比其他第三方开发商开发的浏览器 在 Mac 下使用有天然的优势。**内存占用低 不容易发烫 电池损耗小 续航更久**。当然 作为利器的 Chrome 异常丰富的扩展库 以及它本身的强悍 依旧是我们喜欢的理由。

Safari：

> 咳咳 这次是我的主场...[撇嘴]

Safari 也可以通过为数不多的扩展来强化 变得好用许多 这对于喜欢 Safari 的用户 或者对不插电而以刷网页为主的手指一族 也是一个福音吧。


### Safari  扩展

[AdBlock Plus](https://extensions.apple.com/details/?id=org.adblockplus.adblockplussafari-GRYYZR985A) 屏蔽广告 全平台的广告屏蔽扩展。 

[Instapaper](https://extensions.apple.com/details/?id=com.instapaper.extension-CAM49M58WK) Instapaper 的官方应用。 

[Awesome Screenshot](http://s3.amazonaws.com/diigo/as/AS-1.0.safariextz) 屏幕截图工具——截图快手。

[Evernote Web Clipper](http://update.evernote.com/public/ENMac/SafariExtension/Evernote.1.0.0.safariextz)  Evernote 的文字抓取工具

[Pocket](http://getpocket.com/apps/link/pocket-safari/?ep=4&s=SAFARI_GALLERY) Pocket 的扩展程序

[RackTrack](http://sidetree.com/extensions/BackTrack.safariextz)  以图搜图

[Youku html5 Player](http://zythum.sinaapp.com/youkuhtml5playerbookmark/)  THML5 看视频 不发热 稳定续航时间。

### 更多扩展下载

[Apple Safari Extensions Store](https://extensions.apple.com/?category=mostpopular)  

[Canisbos Safari Extensions](http://canisbos.com/overview)