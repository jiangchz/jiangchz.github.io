# Microdust 微尘

This is a blog created by Azeril. The blog is live at [azeril.me](http://azeril.me/).

## Thanks

The blog used many tool/service,many thanks to:

* [Github](https://github.com/), all the data based on;
* [Git](https://git-scm.com/), blogs and code files version control system;
* [Jekyll](http://jekyllrb.com/), a static site generator;
* [Clean Blog Theme](https://github.com/IronSummitMedia/startbootstrap-clean-blog-jekyll), a theme by Start Bootstrap;
* [Markdown](https://daringfireball.net/projects/markdown/), a beautiful lightweight markup language.
* [DNSPod](https://www.dnspod.cn/), the DNS service provider who surport the domain name resolution;
* [Duoshuo](http://duoshuo.com/), a socialization comments plugin.
* [Google](http://google.com), the one who tell me how to make it.
* …

## How To Creat A Jekyll Blog

[Build-Your-First-GitHub-Pages-Blog](http://azeril.me/blog/Build-Your-First-GitHub-Pages-Blog.html)

Build your blog Step by step
## Just write

Start writing now！
